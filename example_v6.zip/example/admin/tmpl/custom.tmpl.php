<div class="box">
	<div class="box-body">
		<div id=app>
			Admin Custom Page
			<br><br>
			Hier wurde das Submenu in der render() gesetzt!
		</div>
	</div>
</div>