<div class="box">
	<div class="box-body">
		<div>Hier ein Beispiel mit JavaScript</div>
		<div id="app"></div>
	</div>
</div>