

document.addEventListener("DOMContentLoaded", function() {

  console.log('Page was loaded')
  document.getElementById('app').innerHTML = globals.testData;
  
});