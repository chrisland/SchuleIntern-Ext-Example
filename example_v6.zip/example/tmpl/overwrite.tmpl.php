<div class="box">
	<div class="box-body">
		<div id=app>Hier die Overirghts <br> wird aus dem www Ordner überschrieben</div>
	</div>
</div>