<div class="box">
	<div class="box-body">
		<div id="app">Hier der Content aus dem Modul:</div>
        <p><?= $data_class ?></p>
        <p><?= $data_static ?></p>
	</div>
</div>